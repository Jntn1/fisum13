package com.example.fisum13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
